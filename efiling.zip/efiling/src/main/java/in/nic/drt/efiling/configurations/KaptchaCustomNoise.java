package in.nic.drt.efiling.configurations;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.google.code.kaptcha.NoiseProducer;

public class KaptchaCustomNoise implements NoiseProducer {

	@Override
	public void makeNoise(BufferedImage image, float factorOne, float factorTwo, float factorThree, float factorFour) {
		Graphics grp = image.createGraphics();
		int width = image.getWidth();
		int height = image.getHeight();
		
		grp.setColor(Color.BLUE);
		
		for(int i = 0; i < 30; i++) {
			int x1 = (int) (Math.random() * width);
			int y1 = (int) (Math.random() * height);
			int x2 = (int) (Math.random() * width);
			int y2 = (int) (Math.random() * height);
			grp.drawLine(x1, y1, x2, y2);
		}
		
		for(int i = 0; i < 40; i++) {
			int x = (int)(Math.random() * width);
			int y = (int)(Math.random() * height);
			grp.fillRect(x, y, 2, 2);
		}
		int y  = (int) (height * 0.5);
		grp.drawLine(0, y , width, y);
		
		grp.dispose();
		
	}
	
	

}
