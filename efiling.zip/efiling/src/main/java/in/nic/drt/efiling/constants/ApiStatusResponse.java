package in.nic.drt.efiling.constants;

public class ApiStatusResponse {
	
	public static final String captchaFetched = "Captcha fetched successfully "; 

}
