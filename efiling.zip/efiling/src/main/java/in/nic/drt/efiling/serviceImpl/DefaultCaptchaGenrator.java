package in.nic.drt.efiling.serviceImpl;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;


import javax.imageio.ImageIO;

import org.springframework.stereotype.Component;

import com.google.code.kaptcha.impl.DefaultKaptcha;

import in.nic.drt.efiling.service.CaptchaGenerator;


@Component
public class DefaultCaptchaGenrator implements CaptchaGenerator {
	
	
	private Map<String, String> captcha;
	
	
	private DefaultKaptcha defaultKaptcha;
	
	public DefaultCaptchaGenrator(DefaultKaptcha defaultKaptcha){
		this.captcha = new HashMap<>();
		this.defaultKaptcha = defaultKaptcha;
	}

	@Override
	public HashMap<String, String> generateCaptcha() throws java.io.IOException {
		String text = defaultKaptcha.createText();
		BufferedImage image = defaultKaptcha.createImage(text);

		String captchaId = UUID.randomUUID().toString();
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(image, "jpg", baos);
		byte[] imageBytes = baos.toByteArray();
		String base64Image = Base64.getEncoder().encodeToString(imageBytes);
		
		captcha.put(captchaId, text);

		HashMap<String, String> responseData = new HashMap<>();
		responseData.put("captchaId", captchaId);
		responseData.put("captchaImage", "data:image/jpeg;base64," + base64Image);

		return responseData;
	}

	@Override
	public boolean validateCaptcha(String captchaId, String captchaText) {
		
		String storedCaptcha = captcha.get(captchaId);
		if(storedCaptcha == null || storedCaptcha.equals("")) {
			captcha.remove(captchaId);
			return false;
		}
		
		if(storedCaptcha.equals(captchaText)) {
			captcha.remove(captchaId);
			return true;
		}
		captcha.remove(captchaId);
		return false;
	}

}
