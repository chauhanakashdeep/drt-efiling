package in.nic.drt.efiling.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.nic.drt.efiling.constants.ApiStatusResponse;
import in.nic.drt.efiling.dtos.ApiWrapperDto.ApiResponse2;
import in.nic.drt.efiling.serviceImpl.DefaultCaptchaGenrator;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/captcha")
public class CaptchaController {
	
	@Autowired
	DefaultCaptchaGenrator defaultCaptcha;
	
		
	
	@GetMapping("/generate-captcha")
	 public ApiResponse2<Object> login() throws IOException {
       return new ApiResponse2(true, ApiStatusResponse.captchaFetched,  defaultCaptcha.generateCaptcha(), HttpStatus.OK.value());
   }
	
	

}
