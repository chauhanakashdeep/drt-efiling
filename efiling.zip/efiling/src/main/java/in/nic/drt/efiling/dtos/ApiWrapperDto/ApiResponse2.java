package in.nic.drt.efiling.dtos.ApiWrapperDto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;



@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApiResponse2<T> {
	private Boolean status;
	private String message;
	private Object result;
	private int statusCode;

	public ApiResponse2(Boolean status, String message, Object result) {
		this.status = status;
		this.message = message;
		this.result = result;
	}
	
	public ApiResponse2(Boolean status, String message, Object result, Integer statusCode) {
		this.status = status;
		this.message = message;
		this.result = result;
		this.statusCode = statusCode;
	}





}
