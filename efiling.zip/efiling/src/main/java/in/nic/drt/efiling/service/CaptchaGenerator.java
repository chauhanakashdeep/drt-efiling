package in.nic.drt.efiling.service;

import java.io.IOException;
import java.util.HashMap;

public interface CaptchaGenerator {
	
	
	HashMap<String, String> generateCaptcha() throws IOException;
	
	boolean validateCaptcha(String captchaId, String captcha);
}
